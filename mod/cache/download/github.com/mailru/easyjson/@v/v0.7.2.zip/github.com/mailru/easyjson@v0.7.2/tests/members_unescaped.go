package tests

//easyjson:json
type MembersUnescaped struct {
	A string `json:"漢語"`
}
